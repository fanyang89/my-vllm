# TODO: creator function for BlendRetriever and BlendExecutor
